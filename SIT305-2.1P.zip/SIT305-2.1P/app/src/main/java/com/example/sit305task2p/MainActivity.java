package com.example.sit305task2p;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    //Initialising spinner objects
    Spinner categorySpinner;
    Spinner sourceSpinner;
    Spinner destinationSpinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //These lines essentially call 'category, source, and destination spinners from the activity_main.xml for the use of coding functions.
        categorySpinner = findViewById(R.id.category_spinner);
        sourceSpinner = findViewById(R.id.source_spinner);
        destinationSpinner = findViewById(R.id.destination_spinner);


        //Creating a new array that has each of the categories: length, weight, and temperature.
        //Then using ArrayAdapter to convert the spinner into a viewable and interact-able object
        //I made an array here instead of in the strings.xml file as it didn't recognise it that way for some reason?
        String[] categories = new String[]{"Length", "Weight", "Temperature"};
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        //setOnItemSelectedListener in this case will specify what happens when each of the three categories
        //length, weight, or temperature are selected. It will change the dropdown lists accordingly.
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = categories[position];
                ArrayAdapter<CharSequence> adapter;

                //Categories/selectedCategory is used to identify which category is selected from the drop down menu.
                //From there, a switch/case is used to create a 'new' list dependant on which category is chosen in the drop down menu.

                switch (selectedCategory) {
                    case "Temperature": //Temperature category is selected, drop down menu items are swapped with 'temperature_array' items from strings.xml
                        adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.temperature_array, android.R.layout.simple_spinner_item);
                        break;
                    case "Length": //Length category is selected, drop down menu items are swapped with 'length_array' items from strings.xml
                        adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.length_array, android.R.layout.simple_spinner_item);
                        break;
                    case "Weight": //Weight category is selected, drop down menu items are swapped with 'weight_array' items from strings.xml
                        adapter = ArrayAdapter.createFromResource(MainActivity.this, R.array.weight_array, android.R.layout.simple_spinner_item);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + selectedCategory);
                }
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                sourceSpinner.setAdapter(adapter); //Displays certain array items for the source spinner based on the value of 'array' which is determined by the switch/case above.
                destinationSpinner.setAdapter(adapter); //Displays certain array items for the destination spinner based on the value of 'array' which is determined by the switch/case above.
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { //If nothing is selected, nothing should occur, and therefore, this is left empty.
            }
        });


        //Essentially 'calls' the objects 'text, button, and textView' to use for coding.
        //E.g. inputValue will try and find 'text'.
        EditText inputValue = findViewById(R.id.text);
        Button buttonClick = findViewById(R.id.button);
        TextView outputValue = findViewById(R.id.textView);

        buttonClick.setOnClickListener(new View.OnClickListener()
                //this setOnClickListener is used to handle the click event (pressing the button) with 'buttonClick' as the parameter.
        {
            @Override
            public void onClick(View v) { //called when a view has been clicked

                //'sourceSpinner', 'destinationSpinner', and 'inputValue' being initialised
                //These will return the desired values from the respective spinner/text box
                //and return them as a string.
                String sourceUnit = sourceSpinner.getSelectedItem().toString();
                String destinationUnit = destinationSpinner.getSelectedItem().toString();
                String input = inputValue.getText().toString();

                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a number.", Toast.LENGTH_SHORT).show();
                    return;
                    //Returns the text :"please enter a number" if no value is entered on of the button.
                }

                double inputValue = Double.parseDouble(input); //Returns a new double (numerical value) from the specified string (input).
                double result = convert(sourceUnit, destinationUnit, inputValue); //Creating 'result' as a double
                // (numerical value) which the value is based off the caluclated values of the arrays.

                String resultMsg = String.format("%.2f %s", result, destinationUnit);
                outputValue.setText(resultMsg);
                //Creating 'resultMsg' as a string, which will be the text that will be contained next to the 'output' textview.
            }
        });
    }

        private double convertTemperature(String sourceUnit, String destinationUnit, double inputValue) {
            double result = 0; //Setting the initial value of 'result' to 0
            //Initialising 'convertTemperature' which will use the conversion formulas to convert the data
            //between temperature values, and return them to the user.

            switch (sourceUnit) {
                //This switch/case converts the input value from the user into the new value which
                //will be used to convert into another temperature value.
                //The value created will be stored into 'result' to be used in the function below.
                case "Fahrenheit":
                    result = (inputValue - 32) / 1.8;
                    break;

                case "Kelvin":
                    result = inputValue - 273.15;
                    break;

                case "Celsius":
                    result = inputValue;
                    break;
            }

            switch (destinationUnit) {
                //This switch/case will convert the new value of 'result' using the formulas below.
                //For example: result = 2 would mean that the calculation to 'Fahrenheit' would
                //be: (2 * 1.8) + 32.
                case "Fahrenheit":
                    result = (result * 1.8) + 32;
                    break;

                case "Kelvin":
                    result += 273.15;
                    break;

                case "Celsius":
                    break;
            }

            return result; //Returning 'result', which is the converted value.
            }

            private double convertLength(String sourceUnit, String destinationUnit, double inputValue) {
                double result = 0; //Setting the initial value of 'result' to 0
                //Initialising 'convertLength' which will use the conversion formulas to convert the data
                //between length values, and return them to the user.

                switch (sourceUnit) {
                    //Switch/case function based on which source you set for the source spinner
                    // For example: setting your source to "Inch" will mean that the value you put
                    //into the textbox will be set to 'inputValue' which will be times by 2.54.
                    //This number will now be the new value for 'result'.
                    case "Inch":
                        result = inputValue * 2.54;
                        break;

                    case "Foot":
                        result = inputValue * 30.48;
                        break;

                    case "Yard":
                        result = inputValue * 91.44;
                        break;

                    case "Mile":
                        result = inputValue * 160934;
                        break;
                }

                switch (destinationUnit) {
                    //This switch/case function uses the previous function's 'result' value
                    //to convert the input value to the new value.
                    // For example: If inch was selected in the last function, and 2 was the input
                    //the value for result would be 5.08. Lets also say we want to convert it to 'foot'.
                    //This would now take the value of result (2.54) and divide it by 30.48 which gets us
                    //the converted value of 0.17
                    case "Inch":
                        result /= 2.54;
                        break;

                    case "Foot":
                        result /= 30.48;
                        break;

                    case "Yard":
                        result /= 91.44;
                        break;

                    case "Mile":
                        result /= 160934;
                        break;
                }

                return result; //Returning 'result', which is the converted value.
            }

            private double convertWeight(String sourceUnit, String destinationUnit, double inputValue) {
                double result = 0; //Setting the initial value of 'result' to 0
                //Initialising 'convertWeight' which will use the conversion formulas to convert the data
                //between weight values, and return them to the user.


                switch (sourceUnit) {
                    //Like the other switch/case functions above, this one works the exact same way
                    //, converting the input value of the user into a new one using the formulas below.
                    case "Pound":
                        result = inputValue * 453.592;
                        break;

                    case "Ounce":
                        result = inputValue * 28.3495;
                        break;

                    case "Ton":
                        result = inputValue * 907185;
                        break;
                }

                switch (destinationUnit) {
                    //This switch/case function uses the previous function's 'result' value
                    //to convert the input value to the new value.
                    case "Pound":
                        result /= 453.592;
                        break;

                    case "Ounce":
                        result /= 28.3495;
                        break;

                    case "Ton":
                        result /= 907185;
                        break;
                }

                return result; //Returning the 'result' which is the converted value.
            }

            private double convert(String sourceUnit, String destinationUnit, double inputValue) {
            // Initialising the 'convert' function and creating an 'if' scenario to convert values
            //dependant on which array is used.

                if (Arrays.asList("Celsius", "Fahrenheit", "Kelvin").contains(sourceUnit)) {
                    return convertTemperature(sourceUnit, destinationUnit, inputValue);
                    //If the values in the array are "Celsius", "Fahrenheit", "Kelvin", then the function
                    //will use "convertLength" to convert the values set by the user.

                } else if (Arrays.asList("Inch", "Foot", "Yard", "Mile").contains(sourceUnit)) {
                    return convertLength(sourceUnit, destinationUnit, inputValue);
                    //If the values in the array are "inch", "foot", "yard", or "mile", then the function
                    //will use "convertLength" to convert the values set by the user.

                } else {
                    return convertWeight(sourceUnit, destinationUnit, inputValue);
                    //If the arrays are neither 'Temperature' or 'Length' then the 'if' function will assume
                    //the array being used is the 'Weight' one, and convert as such.
                }
            }
}